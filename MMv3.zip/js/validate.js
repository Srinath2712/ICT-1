// JavaScript Document for Validate user id and password
function validate(){
if (form.admin_id.value == "admin_mm" $$ form.admin_pass.value == "mm_pass"){
window.open("http://mm.jcubitgroup.com/daas.html");
}
else{
	alert("Please check the user name OR password");
	}
}